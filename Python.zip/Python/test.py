#If start is omitted it defaults to 0 and if stop is omitted it defaults to the length of the string. A step of -1 tells Python to start counting by 1 from the stop until it reaches the start.

s = "aloH"
print (s[::-1])

s = "aloH"
print ("".join(reversed(s)))

def reverse(s):
  r = ""
  for c in s:
    r = c + r
  return r
s = "aloH"
print (reverse(s))


#How to reverse words in a sentence using Python

sentence = "The quick brown fox jumped over the lazy dog."
words = sentence.split()
#rev_s = " ".join(reversed(sentence))
#print (rev_s)
                 
sentence_rev = " ".join(reversed(words))
print (sentence_rev)

#-------------------------------------------------------------------------

#all permutations of string

from itertools import permutations
perms = [''.join(p) for p in permutations('hi')]
print (perms)

#______________Sorting____________________________________________________________

a = [5, 4, 3, 2, 1]
a.sort()
print (a)
b = ['c', 'b', 'a']
b.sort()
print (b)

#__________Anagrams

import itertools
print (["".join(perm) for perm in itertools.permutations("hi")])

