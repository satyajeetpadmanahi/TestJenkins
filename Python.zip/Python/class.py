class MyClass:
    variable = "Python"

    def function(self):
        print("This is a message inside the MyClass.")

myobjectx = MyClass()

print(myobjectx.variable)

myobjectx.function()
