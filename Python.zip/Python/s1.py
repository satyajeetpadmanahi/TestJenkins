import time
print ("Hellow World!")
#x= 0
x = int(input("Enter a value for x: "))
if x > 0 :
    print ("x is greater than 0")
    print (x)
elif x < 0:
    print ("x is less than 0")

else :
    print ("x is equals to 0")



name = "Don"
print (name)
def fun1():
    name = "Tom"
    print (name)
fun1()

def avg_number(x, y):  
    print("Average of ",x," and ",y, " is ",(x+y)/2)  

x1 = int(input("Enter a value for x1: "))
y1 = int(input("Enter a value for y1: "))
avg_number(x1, y1)

print (time.ctime())

